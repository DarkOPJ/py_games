def max_screen(the_screen):
    """ Maximizes the turtle screen and removes close, minimize and maximize buttons """
    the_screen.setup(width=1.0, height=1.0)
    # remove close,minimize ,maximize buttons:
    canvas = the_screen.getcanvas()
    root = canvas.winfo_toplevel()
    root.overrideredirect(True)

    # top left corner dimensions x= -680 y= 380
    # bottom left corner dimensions x= -680 y= -375
    # top right corner dimensions x= 673 y= 380
    # bottom right corner dimensions x= 673 y= -375
    # x plane = -680 to 673
    # y plane = 380 to -375



# timmy = tt.Turtle()
# timmy.color("White")
#
#
# def move():
#     timmy.fd(40)
#
#
# def move_up():
#     timmy.setheading(90)
#
#
# def move_down():
#     timmy.setheading(270)
#
#
# def move_left():
#     timmy.setheading(180)
#
#
# def move_right():
#     timmy.setheading(0)
#
#
# screen.listen()
#
# screen.onkey(key='Left', fun=move_left)
# screen.onkey(key='Right', fun=move_right)
# screen.onkey(key='Up', fun=move_up)
# screen.onkey(key='Down', fun=move_down)
# # game = True
# # while game:
# #     time.sleep(.3)
# #     move()


    # def move_down(self):
    #     self.game_screen.tracer(0)
    #     for i in self.square_turtle_list:
    #         i.backward(40)
    #     self.game_screen.update()

# SQUARE_TURTLE_POSITIONS_FOR_PADDLE_1 = [(-650, 40), (-650, 30), (-650, 20), (-650, 10), (-650, 0),
#                                         (-650, -10), (-650, -20), (-650, -30), (-650, -40)]
# SQUARE_TURTLE_POSITIONS_FOR_PADDLE_2 = [(643, 40), (643, 20), (643, 0), (643, -20), (643, -40),
#                                         (643, 30), (643, 10), (643, -10), (643, -30)]




