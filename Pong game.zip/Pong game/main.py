import random
import time
import functions as f
import turtle as tt
from paddles import Paddle
from scoreboard import Scoreboard
from ball import Ball
from pitch_drawing import Pitch

screen = tt.Screen()
screen.title("Pong")
screen.bgcolor('Black')
referee = tt.Turtle()
referee.pu()
referee.hideturtle()
referee.color("White")
referee.goto(-210, 0)

# maximizing screen
f.max_screen(screen)

screen.tracer(0)
# scoreboard creation
score = Scoreboard()
player_1_score = 0
player_2_score = 0

# ball creation
ball = Ball()

# paddle creation
paddle_1 = 1
p1 = Paddle(paddle_1, screen)
paddle_2 = 2
p2 = Paddle(paddle_2, screen)
screen.update()

# movement of paddles
screen.listen()
screen.onkey(key="w", fun=p1.move_up)
screen.onkey(key="s", fun=p1.move_down)
screen.onkey(key="Up", fun=p2.move_up)
screen.onkey(key="Down", fun=p2.move_down)
screen.onkey(key="Escape", fun=screen.exitonclick)


# gameplay driving code
pitch = Pitch()
not_out = True
while not_out:
    # ball speed
    time.sleep(.01)
    screen.tracer(0)
    ball.move()

    # collision with the paddles
    evasive_maneuver_for_setheading_90_to_0_and_290_to_360 = [random.randint(0, 70), random.randint(290, 355)]
    for pad in p1.square_turtle_list:
        if pad.distance(ball) < 20:
            if ball.heading() > 180:
                ball.setheading(random.randint(290, 340))
            elif ball.heading() < 180:
                ball.setheading(random.randint(20, 70))
            elif ball.heading() == 180:
                ball.setheading(random.choice(evasive_maneuver_for_setheading_90_to_0_and_290_to_360))
    for pad in p2.square_turtle_list:
        if pad.distance(ball) < 30:
            if ball.heading() == 0:
                ball.setheading(random.randint(110, 250))
            elif ball.heading() > 270:
                ball.setheading(random.randint(200, 250))
                print(ball.heading())
            elif ball.heading() < 90:
                ball.setheading(random.randint(110, 160))
                print(ball.heading())


    # collision with the walls
    if ball.ycor() > 358:
        if 90 > ball.heading() > 0:
            ball.setheading(random.randint(290, 340))
        elif 90 < ball.heading() < 180:
            ball.setheading(random.randint(200, 250))
        elif ball.heading() == 90:
            ball.setheading(random.randint(200, 340))
    elif ball.ycor() < -345:
        if 270 < ball.heading() < 359:
            ball.setheading(random.randint(20, 70))
        elif 180 < ball.heading() < 270:
            ball.setheading(random.randint(110, 160))
        elif ball.heading() == 270:
            ball.setheading(random.randint(20, 160))

    # when ball goes out
    if ball.xcor() > 695:
        paddle_1 = 1
        p1.reset_paddles(paddle_1)
        paddle_2 = 2
        p2.reset_paddles(paddle_2)
        time.sleep(1)
        ball.start_again(0)
        player_1_score += 1
        score.score_1(the_score=player_1_score)
        if player_1_score == 10:
            referee.write("Player 1 wins!", font=("Comic Sans", 50, "normal"))
            not_out = False
    elif ball.xcor() < -700:
        paddle_1 = 1
        p1.reset_paddles(paddle_1)
        paddle_2 = 2
        p2.reset_paddles(paddle_2)
        time.sleep(1)
        ball.start_again(180)
        player_2_score += 1
        score.score_2(the_score=player_2_score)
        if player_2_score == 10:
            referee.write("Player 2 wins!", font=("Comic Sans", 50, "normal"))
            not_out = False
    screen.update()

screen.exitonclick()
