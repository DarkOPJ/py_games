import time
import turtle as tt


class Pitch(tt.Turtle):
    def __init__(self):
        super().__init__()
        self.color("Orange")
        self.pitch_lines()
        self.start_game()
        self.hideturtle()


    def pitch_lines(self):
        self.pu()
        self.goto(-680, 380)
        self.pd()
        self.pensize(5)
        self.goto(672, 380)

        self.setheading(180)
        self.color("Red")
        self.goto(672, -372)

        self.setheading(270)
        self.color("Orange")
        self.goto(-680, -372)

        self.setheading(90)
        self.color("Red")
        self.goto(-680, 389)
        self.pu()
        self.home()

        drawing = True
        self.pd()
        self.pensize(1)
        self.color("Chocolate")
        self.seth(90)
        while drawing:
            self.circle(100)
            self.right(10)
            if self.heading() == 90:
                drawing = False
        self.pu()

        self.goto(0, -372)
        self.pensize(5)
        for dashes in range(6):
            self.pd()
            self.forward(15)
            self.pu()
            self.forward(15)

        self.pu()
        self.goto(0, 372)
        self.pensize(5)
        for dashes in range(6):
            self.pd()
            self.backward(15)
            self.pu()
            self.backward(15)

    @staticmethod
    def start_game():
        starter = tt.Turtle()
        starter.hideturtle()
        starter.goto(0, -50)
        starter.color("White")
        starter.speed(2)
        for _ in range(3, 0, -1):
            starter.clear()
            starter.write(f"{_}", align="center", font=("Comic Sans", 80, "normal"))
            time.sleep(.6)
            starter.clear()
            starter.write('', align="center", font=("Comic Sans", 80, "normal"))
            time.sleep(.6)
