import turtle as tt


class Scoreboard:
    def __init__(self):
        self.score_turtle_list = []
        self.score_turtles()
        self.score_1(0)
        self.score_2(0)


    def score_turtles(self):
        for _ in range(2):
            tim = tt.Turtle()
            tim.color("Orange")
            tim.pu()
            tim.hideturtle()
            self.score_turtle_list.append(tim)



    def score_1(self, the_score):
        self.score_turtle_list[0].clear()
        self.score_turtle_list[0].goto(-100, 300)
        self.score_turtle_list[0].write(f"{the_score}", font=("Comic Sans", 50, "normal"))


    def score_2(self, the_score):
        self.score_turtle_list[1].clear()
        self.score_turtle_list[1].goto(60, 300)
        self.score_turtle_list[1].write(f"{the_score}", font=("Comic Sans", 50, "normal"))
