import turtle as tt
SQUARE_TURTLE_POSITIONS_FOR_PADDLE_1 = [(-650, 40), (-650, 20), (-650, 0), (-650, -20), (-650, -40)]
SQUARE_TURTLE_POSITIONS_FOR_PADDLE_2 = [(643, 40), (643, 20), (643, 0), (643, -20), (643, -40)]


class Paddle:
    def __init__(self, paddle_number, screen):
        self.square_turtle_list = []
        self.game_screen = screen
        self.create_paddle(paddle_number)
        self.head = self.square_turtle_list[0]
        self.tail = self.square_turtle_list[-1]


    def create_square_turtle(self):
        tim = tt.Turtle()
        tim.speed("fast")
        tim.color("Blue")
        tim.shape("square")
        tim.pu()
        tim.setheading(90)
        self.square_turtle_list.append(tim)


    def create_paddle(self, paddle_number):
        if paddle_number == 1:
            starting_position = SQUARE_TURTLE_POSITIONS_FOR_PADDLE_1
        else:
            starting_position = SQUARE_TURTLE_POSITIONS_FOR_PADDLE_2
        for position in starting_position:
            self.create_square_turtle()
            self.square_turtle_list[-1].goto(position)


    def reset_paddles(self, paddle_number):
        iterate = 0
        if paddle_number == 1:
            starting_position = SQUARE_TURTLE_POSITIONS_FOR_PADDLE_1
        else:
            starting_position = SQUARE_TURTLE_POSITIONS_FOR_PADDLE_2
        for position in starting_position:
            self.square_turtle_list[iterate].goto(position)
            iterate += 1


    def move_up(self):
        if self.tail.ycor() < 280:
            self.game_screen.tracer(0)
            for i in self.square_turtle_list:
                i.forward(70)
            self.game_screen.update()

        # For smooth movement of paddles. A bit glitchy
        # smooth_moving = 0
        # if self.tail.ycor() < 280:
        #     while smooth_moving < 100:
        #         self.game_screen.tracer(0)
        #         for i in [4, 3, 2, 1, 0]:
        #             self.square_turtle_list[i].forward(2)
        #             smooth_moving += 1
        #             self.game_screen.update()


    def move_down(self):
        if self.tail.ycor() > -340:
            self.game_screen.tracer(0)
            for i in self.square_turtle_list:
                i.backward(60)
            self.game_screen.update()

        # For smooth movement of paddles. A bit glitchy
        # smooth_moving = 0
        # if self.tail.ycor() > -340:
            # while smooth_moving < 100:
            #     self.game_screen.tracer(0)
            #     for i in self.square_turtle_list:
            #         i.backward(2)
            #         smooth_moving += 1
            #         self.game_screen.update()

    def dragging(self):
        for i in self.square_turtle_list:
            tt.goto
