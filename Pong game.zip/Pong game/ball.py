import random
import turtle as tt


class Ball(tt.Turtle):
    def __init__(self):
        super().__init__("circle")
        self.color("White")
        self.speed(10)
        self.pu()
        self.home()
        self.play_it_to = [0, 180]
        self.setheading(random.choice(self.play_it_to))


    def move(self):
        self.forward(8)


    def start_again(self, play_to):
        self.home()
        self.setheading(play_to)
