def crashed_into_wall(snake):
    if snake.head.xcor() > 300 or snake.head.xcor() < -300 or snake.head.ycor() > 270 or snake.head.ycor() < -300:
        return True


def time_for_large_food(large_food, large_food_counter):
    if large_food.in_the_field:
        large_food_counter[0] += 1
        if large_food_counter[0] > 34:
            print(large_food_counter[0])
            large_food.not_in_the_field()
            large_food_counter[0] = 0
    elif not large_food.in_the_field:
        large_food_counter[0] = 0
