from turtle import Turtle


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.boarder()
        self.color('White')
        self.hideturtle()
        self.pu()
        self.high_score = self.high_score_retriever()
        self.score = 0
        self.write_the_score()

    @staticmethod
    def boarder():
        tim = Turtle()
        tim.color("Grey")
        tim.pu()
        tim.hideturtle()
        tim.goto(-310, 288)
        tim.pd()
        tim.pensize(30)
        tim.forward(650)


    def write_the_score(self):
        self.goto(0, 275)
        self.clear()
        self.write(f'Your score: {self.score} High score: {self.high_score}', align='center', font=('Comic Sans', 14, 'normal'))


    def resetting(self):
        if self.score > self.high_score:
            self.high_score = self.score
            self.high_score_updater()
        self.score = 0


    @staticmethod
    def high_score_retriever():
        with open("data.txt") as high_score_database:
            return int(high_score_database.read())


    def high_score_updater(self):
        with open("data.txt", mode='w') as high_score_database:
            high_score_database.write(f"{self.high_score}")


    def game_over(self):
        self.goto(0, 0)
        self.color('White')
        self.pu()
        self.hideturtle()
        self.write(arg=f'Game Over', align='center', font=('Comic Sans', 20, 'bold'))
        self.resetting()
