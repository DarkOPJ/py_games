import time
import turtle as tt


class Snake:
    def __init__(self):
        self.turtles = []
        self.initial_positions = [(0, 0), (-1, 0), (-2, 0)]
        self.snake_skin = 0
        self.snake()
        self.head = self.turtles[0]
        self.dead = False


    def create_turtle(self):
        tim = tt.Turtle("square")
        tim.speed(10)
        tim.pu()
        if self.snake_skin % 2 == 0:
            tim.color("Dark green")
            self.snake_skin += 1
        else:
            tim.color("Maroon")
            self.snake_skin += 1
        tim.shapesize(stretch_len=.5, stretch_wid=.5)
        tim.goto(400, 400)
        self.turtles.append(tim)


    def snake(self):
        counter = 0
        for position in self.initial_positions:
            self.create_turtle()
            self.turtles[counter].showturtle()
            self.turtles[counter].goto(position)
            counter += 1


    def eaten(self, food, large_food, scoreboard):
        if self.head.distance(food) < 15:
            food.eaten()
            scoreboard.score += 1
            scoreboard.write_the_score()
            self.create_turtle()
        elif self.head.distance(large_food) < 15:
            large_food.not_in_the_field()
            scoreboard.score += 3
            scoreboard.write_the_score()
            for _ in range(3):
                self.create_turtle()


    def facing_a_wall(self):
        for individual_turtle in self.turtles:
            if individual_turtle.xcor() > 290 or individual_turtle.xcor() < -290:
                individual_turtle.goto(-(individual_turtle.xcor()), individual_turtle.ycor())
            elif individual_turtle.ycor() > 270:
                individual_turtle.goto(individual_turtle.xcor(), -(individual_turtle.ycor()))
            elif individual_turtle.ycor() < -290:
                individual_turtle.goto(individual_turtle.xcor(), 270)


    def bite_your_tail(self):
        for individual_turtle in self.turtles[1:]:
            if self.head.distance(individual_turtle) < 10:
                self.dead = True


    def move(self):
        for individual in range(len(self.turtles)-1, 0, -1):
            self.turtles[individual].goto(self.turtles[individual-1].position())
        self.head.forward(15)


    def left(self):
        if self.head.heading() == 90 or self.head.heading() == 270:
            self.head.seth(180)
        

    def right(self):
        if self.head.heading() == 90 or self.head.heading() == 270:
            self.head.seth(0)


    def up(self):
        if self.head.heading() == 0 or self.head.heading() == 180:
            self.head.seth(90)


    def down(self):
        if self.head.heading() == 0 or self.head.heading() == 180:
            self.head.seth(270)
