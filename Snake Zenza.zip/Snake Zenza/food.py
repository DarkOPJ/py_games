import turtle as tt
import random


class Food(tt.Turtle):
    def __init__(self):
        super().__init__("circle")
        self.food_eaten = 0
        self.pu()
        self.color("Blue")
        self.shapesize(stretch_len=.6, stretch_wid=.6)
        self.goto(random.randint(-270, 270), random.randint(-270, 260))


    def eaten(self):
        self.goto(random.randint(-270, 270), random.randint(-270, 260))
        self.food_eaten += 1


class BigFood(Food):
    def __init__(self):
        super().__init__()
        self.shape('turtle')
        self.color("Pale green")
        self.shapesize(stretch_len=1, stretch_wid=1)
        self.in_the_field = False
        self.not_in_the_field()


    def infield(self):
        self.goto(random.randint(-270, 270), random.randint(-270, 260))
        self.in_the_field = True


    def not_in_the_field(self):
        self.goto(500, 500)
        self.in_the_field = False
