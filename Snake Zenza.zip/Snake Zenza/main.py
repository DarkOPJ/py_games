import turtle as tt
import time
import functions
from snake import Snake
from food import Food, BigFood
from scoreboard import Scoreboard

# screen creation
screen = tt.Screen()
screen.title("Snake Zenza")
screen.setup(height=600, width=600)
screen.bgcolor("Black")

# animation stopper
screen.tracer(0)

# difficulty level
difficulty = screen.textinput(title="Difficulty.", prompt="Choose your difficulty(Easy/Hard)").lower()

# snake creation
snake = Snake()
# food creation
food = Food()
large_food = BigFood()
large_food_counter = [0]
# scoreboard creation
scoreboard = Scoreboard()

# keyboard controls
screen.listen()
screen.onkey(key="Left", fun=snake.left)
screen.onkey(key="Right", fun=snake.right)
screen.onkey(key="Up", fun=snake.up)
screen.onkey(key="Down", fun=snake.down)

game_over = False
if difficulty == "easy" or difficulty == "hard":
    game_over = False
else:
    game_over = True

while not game_over:
    # speed
    time.sleep(0.1)

    # snake movement
    snake.move()

    # if snake has eaten
    snake.eaten(food, large_food, scoreboard)

    # bringing large food in and its time
    if food.food_eaten == 6:
        large_food.infield()
        food.food_eaten = 0
    functions.time_for_large_food(large_food, large_food_counter)

    # wall collision
    if difficulty == "easy":
        snake.facing_a_wall()
    else:
        game_over = functions.crashed_into_wall(snake)
        if game_over:
            break

    # tail collision
    snake.bite_your_tail()
    game_over = snake.dead

    # animation refresher
    screen.update()

# game over sequence
scoreboard.game_over()

screen.exitonclick()
