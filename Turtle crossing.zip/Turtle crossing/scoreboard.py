import turtle as tt


class Scoreboard(tt.Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.pu()
        self.color("White")
        self.x = -60
        self.level_reached(1)
        self.finish_line()
        self.message = "Game Over"
        self.time = 40
        self.time_turtle = tom = tt.Turtle()
        self.time_turtle.hideturtle()
        self.countdown()


    def finish_line(self):
        y = 285
        for _ in ["White", 'green', "White", 'green', "White", 'green', "White"]:
            tim = tt.Turtle('square')
            tim.pu()
            tim.color(_)
            tim.goto(self.x, y)
            self.x += 20
        y, x = 265, -60
        for _ in ['green', "White", 'green', "White", 'green', "White", 'green']:
            tim = tt.Turtle('square')
            tim.pu()
            tim.color(_)
            tim.goto(x, y)
            x += 20


    def level_reached(self, level):
        self.clear()
        self.color("White")
        self.goto(-280, 260)
        self.write(f"Level: {level}", font=("Comic Sans", 25, "normal"))


    def game_over_sequence(self):
        self.home()
        self.pu()
        self.color("White")
        self.write(self.message, align="center", font=("Comic Sans", 30, "normal"))


    def countdown(self):
        self.time_turtle.hideturtle()
        self.time_turtle.pu()
        self.time_turtle.color("White")
        self.time_turtle.goto(210, 260)
        self.time_turtle.write(f'Time: {self.time}', align="center", font=("Comic Sans", 20, "normal"))


    def clearing(self):
        self.time_turtle.clear()
