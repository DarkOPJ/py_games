import turtle as tt


class Pedestrian(tt.Turtle):
    def __init__(self, score):
        super().__init__()
        self.shape("turtle")
        self.pu()
        self.color("Gray")
        self.setheading(90)
        self.goto(0, -280)
        self.level = 1
        self.score = score


    def walking(self):
        self.forward(10)


    def level_up(self):
        if self.ycor() > 270:
            self.goto(0, -280)
            self.level += 1
            self.score.level_reached(self.level)
            self.score.clearing()
            self.score.time = 40
            return True
