import random
import time
import turtle as tt

# car colours
colors = 'yellow, gold, orange, red, maroon, violet, magenta, purple, navy, blue'
CAR_COLOURS = colors.split(", ")


class Car(tt.Turtle):
    def __init__(self, car_list_1, pedestrian, speed):
        super().__init__()
        self.shapesize(stretch_wid=1, stretch_len=2)
        self.car_speed = speed
        self.shape("square")
        self.pu()
        self.setheading(180)
        self.color(random.choice(CAR_COLOURS))
        self.goto(320, random.randint(-240, 240))
        self.car_list = car_list_1
        self.timmy = pedestrian


    def minimize_number_of_cars(self, real_amount_of_cars):
        formula = (len(real_amount_of_cars) - 1)


        def difficult_level_cars():
            if self.car_speed >= 15:
                return formula % 2 == 0


        if self.car_list[0] is None:
            self.car_list[0] = real_amount_of_cars[0]
        else:
            if formula % 39 == 0 or formula % 29 == 0 or formula % 11 == 0 or difficult_level_cars():
                self.car_list.append(real_amount_of_cars[formula])
            if len(real_amount_of_cars) > 100:
                real_amount_of_cars.clear()


    def accelerate(self):
        for _ in range(len(self.car_list)):
            if self.car_list[_].xcor() > -350:
                self.car_list[_].forward(self.car_speed)
        time.sleep(0.1)


    def accident(self):
        for individual_car in self.car_list:
            if individual_car.distance(self.timmy) < 25 and individual_car.ycor()+17 > self.timmy.ycor():
                return True
