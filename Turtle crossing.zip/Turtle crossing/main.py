import time
import turtle as tt
from pedestrian import Pedestrian
from cars import Car
from scoreboard import Scoreboard

# screen setup
screen = tt.Screen()
screen.setup(width=600, height=600)
screen.bgcolor("Black")
screen.title("Turtle Crossing")
screen.listen()


# list of cars
car_list = []
car_list_1 = [None]

# stop screen
screen.tracer(0)

# keeping scores and game over
score = Scoreboard()

# pedestrian turtle creation
timmy_is_crossing = Pedestrian(score)

# keyboard controls
screen.onkey(key="Up", fun=timmy_is_crossing.walking)

# game driving code
knocked_down = False
car_speed = 5
loop_times = 0
while not knocked_down:
    # countdown timer
    loop_times += 1
    score.countdown()
    if loop_times % 9 == 0:
        score.clearing()
        score.time -= 1
        score.countdown()
        if score.time < 1:
            break

    # individual cars being created
    car = Car(car_list_1, timmy_is_crossing, car_speed)
    car_list.append(car)

    # minimizing number of cars on screen
    car.minimize_number_of_cars(car_list)

    # cars driving forward and speed
    car.accelerate()

    # detect an accident
    knocked_down = car.accident()

    # level up
    if timmy_is_crossing.level_up():
        if car_speed < 31:
            car_speed += 5

    # refresh screen
    screen.update()

# game over display
score.game_over_sequence()

screen.exitonclick()
